library(ggplot2)
library(dplyr)

df <- read.csv("workdata/NEW_POLICYDATA.csv")

policy_sector_data <- df %>%
  group_by(Sector, PolicyType) %>%
  summarise(count = n(), .groups = "drop")  

# die Farben bestimmen
custom_colors <- c("market-based instrument" = "#1976D2",  
                   "non market-based instrument" = "orange")  

# Zeichnen  ein  Säulendiagramm
ggplot(policy_sector_data, aes(x = Sector, y = count, fill = PolicyType)) +
  geom_bar(stat = "identity", position = "stack") +  
  labs(title = "Policy Type Distribution by Sector",
       x = "Sector",
       y = "Count",
       fill = "Policy Type") +
  scale_fill_manual(values = custom_colors) +  
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))